export class CreateTemplateDto {}
