export interface Exception {
  statusCode: number;
  errCode: number;
  errMsg: string;
}
