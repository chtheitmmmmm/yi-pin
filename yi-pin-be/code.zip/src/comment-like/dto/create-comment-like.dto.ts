export class CreateCommentLikeDto {}
